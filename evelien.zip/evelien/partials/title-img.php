
<h1> 
    <img src="<?= get_template_directory_uri() ?>/images/icon.png" alt="icoon">IMG: 
    <?php the_title() ?> 
</h1>

<hr>
<p> (partial test img)