<hr>
<h1>Titel van functies: <?php the_title() ?> </h1>
<hr>
