
<h1>Titel: <?php the_title() ?> </h1>
<hr>
<p> (partial test)