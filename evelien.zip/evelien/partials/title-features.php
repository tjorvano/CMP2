
<h1>Titel van features: <?php the_title() ?> </h1>
<hr>
